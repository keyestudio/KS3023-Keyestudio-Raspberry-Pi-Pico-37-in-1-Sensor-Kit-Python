'''
 * Keyestudio 37 in 1 Starter Kit for Raspberry Pi Pico
 * lesson 3
 * Laser
 * http://www.keyestudio.com
'''
from machine import Pin
import time

laser = Pin(2, Pin.OUT)# define laser, connect the laser module to pin 2 and set the pin to output mode.
while True:
    laser.value(1)# light up the laser
    time.sleep(2)# delay 2s
    laser.value(0)# turn off the laser
    time.sleep(2)# delay 2s