'''
 * Keyestudio 37 in 1 Starter Kit for Raspberry Pi Pico
 * lesson 55
 * Comprehensive experiment
 * http://www.keyestudio.com
'''
from machine import Pin, PWM
import time
import random
import dht

pwm_r = PWM(Pin(2))
pwm_g = PWM(Pin(3))
pwm_b = PWM(Pin(4))

pwm_r.freq(1000)
pwm_g.freq(1000)
pwm_b.freq(1000)

pin = machine.Pin(19, machine.Pin.OUT, machine.Pin.PULL_DOWN)
xht = dht.DHT11(pin)

potentiometer = machine.ADC(28)
button = Pin(16, Pin.IN)
led = PWM(Pin(14))
led.freq(1000)
ird = Pin(11,Pin.IN)
B = machine.Pin(22, machine.Pin.IN)
X = machine.ADC(26)
Y = machine.ADC(27)
avoid = Pin(0, Pin.IN)
# Set the two pins of ultrasonic sensor
trigger = Pin(6, Pin.OUT)
echo = Pin(7, Pin.IN)

def light(red, green, blue):
    pwm_r.duty_u16(red)
    pwm_g.duty_u16(green)
    pwm_b.duty_u16(blue)

act = {"1": "LLLLLLLLHHHHHHHHLHHLHLLLHLLHLHHH","2": "LLLLLLLLHHHHHHHHHLLHHLLLLHHLLHHH","3": "LLLLLLLLHHHHHHHHHLHHLLLLLHLLHHHH",
       "4": "LLLLLLLLHHHHHHHHLLHHLLLLHHLLHHHH","5": "LLLLLLLLHHHHHHHHLLLHHLLLHHHLLHHH","6": "LLLLLLLLHHHHHHHHLHHHHLHLHLLLLHLH",
       "7": "LLLLLLLLHHHHHHHHLLLHLLLLHHHLHHHH","8": "LLLLLLLLHHHHHHHHLLHHHLLLHHLLLHHH","9": "LLLLLLLLHHHHHHHHLHLHHLHLHLHLLHLH",
       "0": "LLLLLLLLHHHHHHHHLHLLHLHLHLHHLHLH","Up": "LLLLLLLLHHHHHHHHLHHLLLHLHLLHHHLH","Down": "LLLLLLLLHHHHHHHHHLHLHLLLLHLHLHHH",
       "Left": "LLLLLLLLHHHHHHHHLLHLLLHLHHLHHHLH","Right": "LLLLLLLLHHHHHHHHHHLLLLHLLLHHHHLH","Ok": "LLLLLLLLHHHHHHHHLLLLLLHLHHHHHHLH",
       "*": "LLLLLLLLHHHHHHHHLHLLLLHLHLHHHHLH","#": "LLLLLLLLHHHHHHHHLHLHLLHLHLHLHHLH"}

def read_ircode(ird):
    wait = 1
    complete = 0
    seq0 = []
    seq1 = []

    while wait == 1:
        if ird.value() == 0:
            wait = 0
    while wait == 0 and complete == 0:
        start = time.ticks_us()
        while ird.value() == 0:
            ms1 = time.ticks_us()
        diff = time.ticks_diff(ms1,start)
        seq0.append(diff)
        while ird.value() == 1 and complete == 0:
            ms2 = time.ticks_us()
            diff = time.ticks_diff(ms2,ms1)
            if diff > 10000:
                complete = 1
        seq1.append(diff)

    code = ""
    for val in seq1:
        if val < 2000:
            if val < 700:
                code += "L"
            else:
                code += "H"
    # print(code)
    command = ""
    for k,v in act.items():
        if code == v:
            command = k
    if command == "":
        command = code
    return command


# Detect the distance through ultrasonic wave, unit: cm
def getDistance(trigger, echo):
    # generate a square wave of 10us
    trigger.low()   #begin with a short low level, to ensure that the high pluse is clear
    time.sleep_us(2)
    trigger.high()
    time.sleep_us(10)#after the power level is pulled up, wait 10ms, set to a low level immediately
    trigger.low()
    
    while echo.value() == 0: #while loop, detect whether the value is 0 at the echo pin, record the time
        start = time.ticks_us()
    while echo.value() == 1: #while loop, detect whether the value is 1 at the echo pin, record the time
        end = time.ticks_us()
    d = (end - start) * 0.0343 / 2 #distance = duration (from the echo being detected to the wave being sene) x velocity of sound  (343.2 m/s, or 0.0343cm/ms) / 2, why devided by 2: the wave made a return
    return d


keys = 0
nums = 0
print(keys % 7)
def toggle_handle(pin):
    global keys
    keys += 1
    print(keys % 7)

button.irq(trigger = Pin.IRQ_FALLING, handler = toggle_handle)

def showRGB():
    R = random.randint(0,65535)
    G = random.randint(0,65535)
    B = random.randint(0,65535)
    light(R, G, B)
    time.sleep(0.3)

def showxht11():
    print("temperature：{} ℃  humidity：{} %".format(xht.temperature, xht.humidity))
    time.sleep(1)

def IRreceive():
    command = read_ircode(ird)
    print(command)

def showJoystick():
    B_value = B.value()
    X_value = X.read_u16()
    Y_value = Y.read_u16()
    print("button:", end = " ")
    print(B_value, end = " ")
    print("X:", end = " ")
    print(X_value, end = " ")
    print("Y:", end = " ")
    print(Y_value)
    time.sleep(0.1)

def adjustLight():
    pot_value = potentiometer.read_u16()
    print(pot_value)
    led.duty_u16(pot_value)
    time.sleep(0.1)

def showAvoid():
    if avoid.value() == 0:
        print("There are obstacles")
    else:
        print("All going well")
    time.sleep(0.1)

def showDistance():
    distance = getDistance(trigger, echo)
    print("The distance is ：{:.2f} cm".format(distance))
    time.sleep(0.1)

while True:
    nums = keys % 7  #button pressed times devided by 7, record its remainder numbers: they are 0, 1, 2, 3, 4, 5 and 6
    if nums == 0:  #show RGB
        showRGB()
    elif nums == 1:  #show the value received by the IR receiver
        IRreceive()
    elif nums == 2:  #display the temperature and humidity value
        showxht11()
    elif nums == 3:  #show the value of the joystick
        showJoystick()
    elif nums == 4:  #light up the LED on the potentiometer
        adjustLight()
    elif nums == 5:  #display the information about obstacles
        showAvoid()
    elif nums == 6:  #print the distance value detected by the ultrasonic sensor
        showDistance()
