'''
 * Keyestudio 37 in 1 Starter Kit for Raspberry Pi Pico
 * lesson 30
 * Ultrasonic
 * http://www.keyestudio.com
'''
from machine import Pin
import utime

# detect the distance by ultrasonic wave, unit: cm
def getDistance(trigger, echo):
    # generate a square wave of 10us
    trigger.low()   #begin with a short low level to ensure that the high pluse is clear
    utime.sleep_us(2)
    trigger.high()
    utime.sleep_us(10)#After the power level is pulled up, wait 10ms, then set to low level immediately
    trigger.low()
    
    while echo.value() == 0: #while loop, detect whether the value is 0 at the echo pin, record the time
        start = utime.ticks_us()
    while echo.value() == 1: #while loop, detect whether the value is 1 at the echo pin, record the time
        end = utime.ticks_us()
    d = (end - start) * 0.0343 / 2 #duration(from echo being detected to wave being sent) x velocity of sound (343.2 m/s, or 0.0343cm/ms) / 2, why devided by 2: the wave made a return
    return d

# set the pin
trigger = Pin(14, Pin.OUT)
echo = Pin(13, Pin.IN)
# major codes
while True:
    distance = getDistance(trigger, echo)
    print("The distance is ：{:.2f} cm".format(distance))
    utime.sleep(0.1)
