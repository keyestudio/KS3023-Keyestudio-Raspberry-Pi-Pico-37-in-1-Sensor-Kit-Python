'''
 * Keyestudio 37 in 1 Starter Kit for Raspberry Pi Pico
 * lesson 29.2
 * Servo test 2
 * http://www.keyestudio.com
'''
from utime import sleep
from machine import Pin
from machine import PWM

pwm = PWM(Pin(0))#Connect servo to pin GP0
pwm.freq(50)#the cycle is 20ms, so the frequency equals 50Hz 
'''
Duty cycle of some angles
0°----2.5%----1638
45°----5%----3276
90°----7.5%----4915
135°----10%----6553
180°----12.5%----8192
In consideration of errors, allocate the duty cycle within 1000~9000, so that the servo is able to rotate from 0° to 180°
'''
# set the rotation angle of the servo
def setServoCycle (position):
    pwm.duty_u16(position)
    sleep(0.01)

# convert the angle into duty cycle
def convert(x, i_m, i_M, o_m, o_M):
    return max(min(o_M, (x - i_m) * (o_M - o_m) // (i_M - i_m) + o_m), o_m)

while True:
    for degree in range(0, 180, 1):#rotate from 0° to 180°
        pos = convert(degree, 0, 180, 1000, 9000)
        setServoCycle(pos)

    for degree in range(180, 0, -1):#rotate from 180° to 0°
        pos = convert(degree, 0, 180, 1000, 9000)
        setServoCycle(pos)
