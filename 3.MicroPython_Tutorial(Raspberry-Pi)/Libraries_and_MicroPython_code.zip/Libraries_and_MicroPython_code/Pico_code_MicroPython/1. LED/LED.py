'''
 * Keyestudio 37 in 1 Starter Kit for Raspberry Pi Pico
 * lesson 1.1
 * turn on led
 * http://www.keyestudio.com
'''
from machine import Pin

led = Pin(0, Pin.OUT)# Define led, and connect LED to pin 0, set pin 0 to output mode

led.value(1)# Light up at high level
    