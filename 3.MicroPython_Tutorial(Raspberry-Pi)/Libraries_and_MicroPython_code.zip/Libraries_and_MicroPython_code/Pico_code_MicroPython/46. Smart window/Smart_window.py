'''
 * Keyestudio 37 in 1 Starter Kit for Raspberry Pi Pico
 * lesson 46
 * Smart_window
 * http://www.keyestudio.com
'''
import utime
from machine import Pin
from machine import PWM

pwm = PWM(Pin(9))#Connect servo to pin GP9
pwm.freq(50)#the cycle is 20ms, so the frequency equals 50Hz
sensor = machine.ADC(26)#ADC0
'''
Duty cycle of some angles
0°----2.5%----1638
45°----5%----3276
90°----7.5%----4915
135°----10%----6553
180°----12.5%----8192
In consideration of errors, allocate the duty cycle within 1000~9000, so that the servo is able to rotate from 0° to 180°
'''
angle_0 = 1638
angle_90 = 4915
angle_180 = 8192
    
while True:
    value = sensor.read_u16()
    print(value)
    if value > 2000:
        pwm.duty_u16(angle_0)
        utime.sleep(0.5)
    else:
        pwm.duty_u16(angle_180)
        utime.sleep(0.5)

    